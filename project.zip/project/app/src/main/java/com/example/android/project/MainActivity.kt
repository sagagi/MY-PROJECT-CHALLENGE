package com.example.android.project

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.app.AlertDialog
import android.view.View
import android.widget.Button

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // ((Button) findViewById(R.id.singlemode)).setClickable(false);
    }
    override fun onCreateOptionsMenu(menu:Menu):Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.main, menu)
        return true
    }
    fun playTwoPGame(view: View) {
        val intent = Intent(this, PlayerName::class.java)
        if (intent.resolveActivity(packageManager) != null) {
            startActivity(intent)
        }

    }

    fun playSinglePGame(view: View) {
        val intent = Intent(this, PlayerNameWithComputer::class.java)
        if (intent.resolveActivity(packageManager) != null) {
            startActivity(intent)
        }
    }

    fun about(view: View) {
        val intent = Intent(this, About::class.java)
        if (intent.resolveActivity(packageManager) != null) {
            startActivity(intent)
        }
    }

    fun exit_click(view: View) {
        val dlgAlert = AlertDialog.Builder(this)

        dlgAlert.setMessage("Do you really want to exit")
        dlgAlert.setTitle("Exit")

        dlgAlert.setCancelable(true)
        dlgAlert.setPositiveButton("Ok"
        ) { dialog, which ->
            finish()
            System.exit(0)
        }
        dlgAlert.create().show()
    }
    //    public void exitGame(View view){
    //        finish();
    //        System.exit(0);
    //    }
}
