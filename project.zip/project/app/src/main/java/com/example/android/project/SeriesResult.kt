package com.example.android.project

/**
 * Created by sagagi on 4/12/2018.
 */
import android.content.Intent
import android.graphics.Color
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView

class SeriesResult : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_series_result)
        val intent = intent
        val player1Wins = intent.extras!!.getInt("Player 1 Wins").toString()
        val player2Wins = intent.extras!!.getInt("Player 2 Wins").toString()
        val draws = intent.extras!!.getInt("Draws").toString()
        val player1Name = intent.extras!!.getString("Player 1 Name")
        val player2Name = intent.extras!!.getString("Player 2 Name")
        val player1NameView = findViewById(R.id.p1name) as TextView
        val player2NameView = findViewById(R.id.p2name) as TextView
        val player1WinsView = findViewById(R.id.p1wins) as TextView
        val player2WinsView = findViewById(R.id.p2wins) as TextView
        val drawsView = findViewById(R.id.draws) as TextView


        if (Integer.parseInt(player1Wins) > Integer.parseInt(player2Wins)) {
            player1NameView.setTextColor(Color.GREEN)
            player2NameView.setTextColor(Color.RED)
        } else if (Integer.parseInt(player1Wins) < Integer.parseInt(player2Wins)) {
            player2NameView.setTextColor(Color.GREEN)
            player1NameView.setTextColor(Color.RED)
        } else {
            player2NameView.setTextColor(Color.YELLOW)
            player1NameView.setTextColor(Color.YELLOW)
        }
        player1NameView.text = player1Name
        player2NameView.text = player2Name
        player1WinsView.text = player1Wins
        player2WinsView.text = player2Wins
        drawsView.text = draws

    }

    fun onClickContinue(view: View) {
        val intent = Intent(this, MainActivity::class.java)
        if (intent.resolveActivity(packageManager) != null) {
            startActivity(intent)
            finish()
        }
    }
}
